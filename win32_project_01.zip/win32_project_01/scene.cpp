#include "stdafx.h"
#include "scene.h"

scene::~scene()
{

}
