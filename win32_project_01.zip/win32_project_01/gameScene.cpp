#include "stdafx.h"
#include "gameScene.h"
//memdc�� �׷��ִ� ����, frame
extern WGameFramework framework;

gameScene::~gameScene()
{

}

void  gameScene::InitSound()
{
	FMOD_System_Create(&System);
	FMOD_System_Init(System, 10, FMOD_INIT_NORMAL, NULL);
	FMOD_System_CreateSound(System, "sound/mainsound.wav", FMOD_LOOP_NORMAL, 0, &bgSound); //stage1�������
	FMOD_System_CreateSound(System, "effect/Coin01.wav", FMOD_DEFAULT, 0, &effectSound[0]); //���� ȹ��
	FMOD_System_CreateSound(System, "effect/Rise02.wav", FMOD_DEFAULT, 0, &effectSound[1]); //��Ʈ ȹ��
	FMOD_System_CreateSound(System, "effect/Rise05.wav", FMOD_DEFAULT, 0, &effectSound[2]); //�浹
	FMOD_System_CreateSound(System, "effect/Rise07.wav", FMOD_DEFAULT, 0, &effectSound[3]); //����
	FMOD_System_CreateSound(System, "effect/Downer01.wav", FMOD_DEFAULT, 0, &effectSound[3]); //����
	FMOD_System_PlaySound(System, bgSound, NULL, 0, &Channel[0]);
	FMOD_Channel_SetVolume(Channel[0], 0.3);
	FMOD_Channel_SetVolume(Channel[1], 0.5);
	FMOD_Channel_SetVolume(Channel[2], 1.0);
}

void gameScene::InitCloud() {       //txt���Ͽ��� ���� ���� �޾ƿ��� �Լ�
	FILE* fp;
	fopen_s(&fp, "image/map1.txt", "r");
	random_device rd;
	uniform_int_distribution <int> dis(0, 49);

	int i = 0;
	if (fp == NULL)//���� ������ ��
	{
		perror("fopen ����");//���� �޽��� ���
		return;
	}

	while (!feof(fp)) {
		fscanf_s(fp, "%d %d %d", &cloud[i].cx, &cloud[i].cy, &cloud[i++].what);
		cloud[i].index = dis(rd);
	}

	cloud_index = i;
	fclose(fp);
}
void gameScene::InitHeart() {
	FILE* fp;
	fopen_s(&fp, "image/map1(heart).txt", "r");

	int i = 0;
	if (fp == NULL)
	{
		perror("fopen ����");
		return;
	}

	while (!feof(fp)) {
		fscanf_s(fp, "%d %d %d", &item[i].ix, &item[i].iy, &item[i].what);
		++i;
	}

	item_index = i;
	fclose(fp);
}
void gameScene::InitAnimation() {
	int j = 0;
	//14��
	//1�ִϸ��̼� 4��
	//0 ~ 3, ... ~39
	for (int i = 0; i < 14; i++) {
		animation[j] = { i * PLAYER_IMAGE_SIZE, 0, (i + 1) * PLAYER_IMAGE_SIZE, PLAYER_IMAGE_SIZE };
		animation[j + 1] = { i * PLAYER_IMAGE_SIZE, 0, (i + 1) * PLAYER_IMAGE_SIZE, PLAYER_IMAGE_SIZE };
		animation[j + 2] = { i * PLAYER_IMAGE_SIZE, 0, (i + 1) * PLAYER_IMAGE_SIZE, PLAYER_IMAGE_SIZE };
		animation[j + 3] = { i * PLAYER_IMAGE_SIZE, 0, (i + 1) * PLAYER_IMAGE_SIZE, PLAYER_IMAGE_SIZE };
		j += 4;
	}

	j = 0;

	//0~4, 5~9, 10~14, 15~19, 20~24, |25~29, 30~34, 35~39, 40~44, 45~49,| 50 ~54, 55~59 ���� ���� �̹����� ���� ��
	//������Ʈ �ӵ��� �ʹ� ���� ������ �����̰� �ϱ� ����

	for (int i = 0; i < 15; i++) {
		if (i == 10 || i == 11) {
			cloud_ani[j] = { 9 * CLOUD_IMAGE_SIZE, 0, 10 * CLOUD_IMAGE_SIZE, CLOUD_IMAGE_SIZE };
			cloud_ani[j + 1] = { 9 * CLOUD_IMAGE_SIZE, 0, 10 * CLOUD_IMAGE_SIZE, CLOUD_IMAGE_SIZE };
			cloud_ani[j + 2] = { 9 * CLOUD_IMAGE_SIZE, 0, 10 * CLOUD_IMAGE_SIZE, CLOUD_IMAGE_SIZE };
			cloud_ani[j + 3] = { 9 * CLOUD_IMAGE_SIZE, 0, 10 * CLOUD_IMAGE_SIZE, CLOUD_IMAGE_SIZE };
			cloud_ani[j + 4] = { 9 * CLOUD_IMAGE_SIZE, 0, 10 * CLOUD_IMAGE_SIZE, CLOUD_IMAGE_SIZE };
		}
		else if (i == 12 || i == 13 || i == 14) {
			cloud_ani[j] = { 0 * CLOUD_IMAGE_SIZE, 0, 1 * CLOUD_IMAGE_SIZE, CLOUD_IMAGE_SIZE };
			cloud_ani[j + 1] = { 0 * CLOUD_IMAGE_SIZE, 0, 1 * CLOUD_IMAGE_SIZE, CLOUD_IMAGE_SIZE };
			cloud_ani[j + 2] = { 0 * CLOUD_IMAGE_SIZE, 0, 1 * CLOUD_IMAGE_SIZE, CLOUD_IMAGE_SIZE };
			cloud_ani[j + 3] = { 0 * CLOUD_IMAGE_SIZE, 0, 1 * CLOUD_IMAGE_SIZE, CLOUD_IMAGE_SIZE };
			cloud_ani[j + 4] = { 0 * CLOUD_IMAGE_SIZE, 0, 1 * CLOUD_IMAGE_SIZE, CLOUD_IMAGE_SIZE };
		}
		else {
			cloud_ani[j] = { i * CLOUD_IMAGE_SIZE, 0, (i + 1) * CLOUD_IMAGE_SIZE, CLOUD_IMAGE_SIZE };
			cloud_ani[j + 1] = { i * CLOUD_IMAGE_SIZE, 0, (i + 1) * CLOUD_IMAGE_SIZE, CLOUD_IMAGE_SIZE };
			cloud_ani[j + 2] = { i * CLOUD_IMAGE_SIZE, 0, (i + 1) * CLOUD_IMAGE_SIZE, CLOUD_IMAGE_SIZE };
			cloud_ani[j + 3] = { i * CLOUD_IMAGE_SIZE, 0, (i + 1) * CLOUD_IMAGE_SIZE, CLOUD_IMAGE_SIZE };
			cloud_ani[j + 4] = { i * CLOUD_IMAGE_SIZE, 0, (i + 1) * CLOUD_IMAGE_SIZE, CLOUD_IMAGE_SIZE };
		}
		j += 5;
	}
	j = 0;
	for (int i = 0; i < 7; i++) {
		if (i == 5 || i == 6) {
			rain_ani[j] = { 4 * CLOUD_IMAGE_SIZE, 0, 5 * CLOUD_IMAGE_SIZE, RAIN_IMAGE };
			rain_ani[j + 1] = { 4 * CLOUD_IMAGE_SIZE, 0, 5 * CLOUD_IMAGE_SIZE, RAIN_IMAGE };
			rain_ani[j + 2] = { 4 * CLOUD_IMAGE_SIZE, 0, 5 * CLOUD_IMAGE_SIZE, RAIN_IMAGE };
			rain_ani[j + 3] = { 4 * CLOUD_IMAGE_SIZE, 0, 5 * CLOUD_IMAGE_SIZE, RAIN_IMAGE };
			rain_ani[j + 4] = { 4 * CLOUD_IMAGE_SIZE, 0, 5 * CLOUD_IMAGE_SIZE, RAIN_IMAGE };
		}
		else {
			rain_ani[j] = { i * CLOUD_IMAGE_SIZE, 0, (i + 1) * CLOUD_IMAGE_SIZE, RAIN_IMAGE };
			rain_ani[j + 1] = { i * CLOUD_IMAGE_SIZE, 0, (i + 1) * CLOUD_IMAGE_SIZE, RAIN_IMAGE };
			rain_ani[j + 2] = { i * CLOUD_IMAGE_SIZE, 0, (i + 1) * CLOUD_IMAGE_SIZE, RAIN_IMAGE };
			rain_ani[j + 3] = { i * CLOUD_IMAGE_SIZE, 0, (i + 1) * CLOUD_IMAGE_SIZE, RAIN_IMAGE };
			rain_ani[j + 4] = { i * CLOUD_IMAGE_SIZE, 0, (i + 1) * CLOUD_IMAGE_SIZE, RAIN_IMAGE };
		}
		j += 5;
	}
}
void gameScene::init()
{
	startX = 0, startY = MEM_HEIGHT - (FRAME_HEIGHT);

	player_image.Load(TEXT("image/������.png"));
	background.Load(TEXT("image/���ȭ��1.png"));

	normalCloud.Load(TEXT("image/�Ϲݱ���.png"));
	rainCloud.Load(TEXT("image/�񱸸�.png"));
	rain.Load(TEXT("image/��.png"));
	darkCloud.Load(TEXT("image/�Ա���.png"));

	heart.Load(TEXT("image/heart.png"));
	stone.Load(TEXT("image/coin.png"));

	InitSound();
	InitAnimation();
	InitCloud();
	InitHeart();
	ani_index = 0;      //�浹�̸� 20~27, ���ø� 0~19
	gravity = 1;
	bar_w = 498;
	bar_startY = PLAYER_FIRSTY + 100;
	fall = true;

	status = RUN;

	player = { MEM_WIDTH / 2, PLAYER_FIRSTY, 1, 0 };      //�÷��̾� ������ġ
}

void gameScene::drawPlayer(HDC hdc) {
	//�÷��̾� �׸��� �Լ�
	player_image.Draw(hdc, player.px, player.py, PLAYER_WIDTH, PLAYER_HEIGHT, animation[ani_index].left, animation[ani_index].top,
		PLAYER_IMAGE_SIZE, PLAYER_IMAGE_SIZE);
}
void gameScene::drawBackGround(HDC hdc) {
	//��� �׸��� �Լ�
	background.BitBlt(hdc, 0, 0, SRCCOPY);
}
void gameScene::drawCloud(HDC hdc) {
	//���� �׸��� �Լ�
	for (int j = 0; j < cloud_index; ++j) {
		switch (cloud[j].what) {
		case 1:
			darkCloud.Draw(hdc, cloud[j].cx, cloud[j].cy, CLOUD_WIDTH, CLOUD_HEIGHT, cloud_ani[cloud[j].index].left, cloud_ani[cloud[j].index].top, CLOUD_IMAGE_SIZE, CLOUD_IMAGE_SIZE);
			break;
		case 2:
			if (cloud[j].index >= 25 && cloud[j].index <= 59) {
				rainCloud.Draw(hdc, cloud[j].cx, cloud[j].cy, CLOUD_WIDTH, CLOUD_HEIGHT - 30, cloud_ani[cloud[j].index].left, cloud_ani[cloud[j].index].top, CLOUD_IMAGE_SIZE, RAINCLOUD_IMAGE);
				rain.Draw(hdc, cloud[j].cx, cloud[j].cy + (CLOUD_HEIGHT - 30), CLOUD_WIDTH, CLOUD_HEIGHT, rain_ani[cloud[j].index - 25].left, rain_ani[cloud[j].index - 25].top, CLOUD_IMAGE_SIZE, RAIN_IMAGE);
			}
			else
				rainCloud.Draw(hdc, cloud[j].cx, cloud[j].cy, CLOUD_WIDTH, CLOUD_HEIGHT - 30, cloud_ani[cloud[j].index].left, cloud_ani[cloud[j].index].top, CLOUD_IMAGE_SIZE, RAINCLOUD_IMAGE);
			break;
		case 3:
			normalCloud.Draw(hdc, cloud[j].cx, cloud[j].cy, CLOUD_WIDTH, CLOUD_HEIGHT, cloud_ani[cloud[j].index].left, cloud_ani[cloud[j].index].top, CLOUD_IMAGE_SIZE, CLOUD_IMAGE_SIZE);
			break;
		}
	}
}
void gameScene::drawItems(HDC hdc) {
	for (int j = 0; j < item_index; ++j) {
		switch (item[j].what) {
		case 1:
			heart.Draw(hdc, item[j].ix, item[j].iy, ITEM_SIZE, ITEM_SIZE, 0, 0, heart.GetWidth(), heart.GetHeight());
			break;
		case 2:
			stone.Draw(hdc, item[j].ix, item[j].iy, ITEM_SIZE, ITEM_SIZE, 0, 0, stone.GetWidth(), stone.GetHeight());
			break;
		}
	}
}
void gameScene::drawHPBar(HDC hdc) {
	HBRUSH myBrush = (HBRUSH)CreateSolidBrush(RGB(150, 50, 0));
	HBRUSH oldBrush = (HBRUSH)SelectObject(hdc, myBrush);
	Rectangle(hdc, 50, bar_startY + 1, bar_w + 50, bar_startY + 29);
	SelectObject(hdc, oldBrush);
	DeleteObject(myBrush);

	myBrush = (HBRUSH)GetStockObject(NULL_BRUSH);
	oldBrush = (HBRUSH)SelectObject(hdc, myBrush);
	HPEN hPen = CreatePen(PS_DOT, 2, RGB(0, 0, 0));
	HPEN oldPen = (HPEN)SelectObject(hdc, hPen);
	Rectangle(hdc, 50, bar_startY, HPBAR_WIDTH + 50, bar_startY + 30);
	SelectObject(hdc, oldBrush);
	DeleteObject(myBrush);
	SelectObject(hdc, oldPen);
	DeleteObject(hPen);
}
void gameScene::drawBox(HDC hdc) {
	Rectangle(hdc, pRECT.left, pRECT.top, pRECT.right, pRECT.bottom);
	for (int i = 0; i < cloud_index; ++i) {
		Rectangle(hdc, cloud[i].cx + 30, cloud[i].cy + 30, cloud[i].cx + CLOUD_COLLIDE_WIDTH, cloud[i].cy + CLOUD_COLLIDE_HEIGHT);
	}

}

void gameScene::moveItem() {
	for (int i = 0; i < item_index; ++i) {
		if (item[i].get == 1) {
			item[i].iy = bar_startY;
		}
	}
}

void gameScene::processKey(UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	switch (iMessage)
	{
	case WM_KEYDOWN:
	{
		if (wParam == VK_ESCAPE) {
			if (status == PAUSE)
				status = RUN;
			else
				status = PAUSE;
			break;
		}
	}
	break;
	case WM_KEYUP:
	{
		if (wParam == VK_UP) {
			fall = true;
			gravity = 1.8;
		}
		else if (wParam == VK_RIGHT || wParam == VK_LEFT) {
			fall = true;
			gravity = 0.5;
		}

	}
	break;
	}
}

bool gameScene::getItemCheck() {
	for (int i = 0; i < item_index; ++i) {
		if (item[i].get == 0)
			return false;
	}
	return true;
}

//�ִϸ��̼� ������ ���⼭ ������Ʈ
void gameScene::Update(const float frameTime)
{
	if (status == PAUSE)
		return;

	if (player.status) {          //�浹�� �ƴ� ��
		ani_index++;
	}
	if (ani_index >= 39)
		ani_index = 0;

	pRECT = { player.px + 18,player.py + 10,player.px + 18 + PLAYER_COLLIDE_WIDTH ,player.py + PLAYER_HEIGHT };

	player.status = 1;

	for (int i = 0; i < cloud_index; ++i) {
		cloud[i].index++;
		if (cloud[i].index == 74)
			cloud[i].index = 0;
		cRECT = { cloud[i].cx + 30, cloud[i].cy + 30, cloud[i].cx + CLOUD_COLLIDE_WIDTH, cloud[i].cy + CLOUD_COLLIDE_HEIGHT };
		if (IntersectRect(&tmp, &cRECT, &pRECT) && i > 6) {                             //�浹 �˻�
			player.status = 0;
			ani_index = 50;
		}
		if (cloud[i].what != 3 && cloud[i].index >= 35 && cloud[i].index <= 59) {       //������ �� �浹 �˻�
			cRECT = { cloud[i].cx + 30, cloud[i].cy + (CLOUD_HEIGHT - 30),              //�� ����
				cloud[i].cx + CLOUD_COLLIDE_WIDTH, cloud[i].cy + (CLOUD_HEIGHT - 30) + CLOUD_HEIGHT };
			if (IntersectRect(&tmp, &cRECT, &pRECT)) {                             //�浹 �˻�
				player.status = 0;
				ani_index = 50;
			}
		}
	}

	if (!player.status) {           //�÷��̾ �浹�����̸� ü�� ����
		bar_w -= 40 * frameTime;
		FMOD_System_PlaySound(System, effectSound[2], NULL, 0, &Channel[1]); //�浹�ϸ� ȿ����
	}
	bar_w -= 0.5 * frameTime;       //�׻� ����

	if (bar_w <= 0) {
		//FMOD_System_PlaySound(System, effectSound[4], NULL, 0, &Channel);
		FMOD_Sound_Release(effectSound[0]);
		FMOD_Sound_Release(effectSound[1]);
		FMOD_Sound_Release(effectSound[2]);
		FMOD_Sound_Release(effectSound[3]);
		FMOD_Sound_Release(effectSound[4]);
		FMOD_Sound_Release(bgSound);
		FMOD_System_Close(System);
		FMOD_System_Release(System);
		scene* scene = framework.curScene;   ////���� ���� tmp�� �ְ� ������
		framework.curScene = new overScene;
		framework.curScene->init();
		framework.nowscene = GAME;
		delete scene;
		return;
	}

	for (int i = 0; i < item_index; ++i) {                                  //�÷��̾ ������ �Ծ����� �˻�
		cRECT = { item[i].ix, item[i].iy, item[i].ix + ITEM_SIZE, item[i].iy + ITEM_SIZE };
		if (IntersectRect(&tmp, &cRECT, &pRECT)) {
			item[i].ix = ITEM_START + i * 40;
			item[i].iy = bar_startY;
			item[i].get = 1;
			if (item[i].what == 1) {
				bar_w = (bar_w + 50 >= 498) ? 498 : bar_w + 30;
				FMOD_System_PlaySound(System, effectSound[1], NULL, 0, &Channel[2]);
			}
			else
				FMOD_System_PlaySound(System, effectSound[0], NULL, 0, &Channel[2]);
		}
	}

	if (fall && gravity >= -30)
		gravity -= frameTime * 12;

	if (fall && player.py <= PLAYER_FIRSTY) {
		if (!player.status)
			player.py -= gravity / 3;
		else
			player.py -= gravity;
		if (startY <= MEM_HEIGHT - (FRAME_HEIGHT) && player.py >= PLAYERMOVE_START) {
			if (!player.status) {
				startY -= gravity / 3;
				bar_startY -= gravity / 3;
				moveItem();
			}
			else {
				startY -= gravity;
				bar_startY -= gravity;
				moveItem();
			}
		}
	}

	if ((GetAsyncKeyState(VK_LEFT) & 0x8000) && (GetAsyncKeyState(VK_UP) & 0x8001)) {
		fall = false;
		if (player.px < 0)
			return;
		if (player.py <= PLAYERMOVE_START || player.py >= PLAYERMOVE_STOP) {
			if (!player.status) {
				player.py -= 2;
				player.px -= 2;
			}
			else {
				player.py -= 7;
				player.px -= 7;
			}

		}
		else {
			if (!player.status) {
				startY -= 2;
				bar_startY -= 2;
				moveItem();
				player.py -= 2;
				player.px -= 2;
			}
			else {
				startY -= 7;
				bar_startY -= 7;
				moveItem();
				player.py -= 7;
				player.px -= 7;
			}
		}
		return;
	}
	if ((GetAsyncKeyState(VK_RIGHT) & 0x8000) && (GetAsyncKeyState(VK_UP) & 0x8001)) {
		fall = false;
		if (player.px + PLAYER_WIDTH > 1190)
			return;
		if (player.py <= PLAYERMOVE_START || player.py >= PLAYERMOVE_STOP) {
			if (!player.status) {
				player.py -= 2;
				player.px += 2;
			}
			else {
				player.py -= 7;
				player.px += 7;
			}

		}
		else {
			if (!player.status) {
				startY -= 2;
				bar_startY -= 2;
				moveItem();
				player.py -= 2;
				player.px += 2;
			}
			else {
				startY -= 7;
				bar_startY -= 7;
				moveItem();
				player.py -= 7;
				player.px += 7;
			}
		}
		return;
	}
	if ((GetAsyncKeyState(VK_UP) & 0x8001)) {
		fall = false;
		if (player.py <= PLAYERMOVE_START || player.py >= PLAYERMOVE_STOP) {
			if (!player.status)
				player.py -= 2;
			else
				player.py -= 7;
		}
		else {
			if (!player.status) {
				startY -= 2;
				bar_startY -= 2;
				moveItem();
				player.py -= 2;
			}
			else {
				startY -= 7;
				bar_startY -= 7;
				moveItem();
				player.py -= 7;
			}
		}
	}
	else if ((GetAsyncKeyState(VK_RIGHT) & 0x8000) || (GetAsyncKeyState(VK_RIGHT) & 0x8001)) {
		if (player.px + PLAYER_WIDTH > 1190)
			return;
		if (!player.status)
			player.px += 2;
		else
			player.px += 5;
	}

	else if ((GetAsyncKeyState(VK_LEFT) & 0x8000) || (GetAsyncKeyState(VK_LEFT) & 0x8001)) {
		if (player.px < 0)
			return;
		if (!player.status)
			player.px -= 2;
		else
			player.px -= 5;
	}
	if (player.py <= 0 && getItemCheck()) {
		//FMOD_System_PlaySound(System, effectSound[3], NULL, 0, &Channel);
		FMOD_Sound_Release(effectSound[0]);
		FMOD_Sound_Release(effectSound[1]);
		FMOD_Sound_Release(effectSound[2]);
		FMOD_Sound_Release(effectSound[3]);
		FMOD_Sound_Release(effectSound[4]);
		FMOD_Sound_Release(bgSound);
		FMOD_System_Close(System);
		FMOD_System_Release(System);
		scene* scene = framework.curScene;   ////���� ���� tmp�� �ְ� ������
		framework.curScene = new clearScene;
		framework.curScene->init();
		framework.nowscene = MENU;
		delete scene;
	}
}
void gameScene::Render(HDC hdc)
{
	drawBackGround(hdc);
	//drawBox(hdc);
	drawPlayer(hdc);
	drawCloud(hdc);
	drawItems(hdc);
	drawHPBar(hdc);
}



//void gameScene::Release() {
//
//
//}
